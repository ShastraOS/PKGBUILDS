#![cfg_attr(RUSTC_WITH_SPECIALIZATION, feature(min_specialization))]
pub mod bloom;

#[macro_use]
extern crate solana_frozen_abi_macro;
