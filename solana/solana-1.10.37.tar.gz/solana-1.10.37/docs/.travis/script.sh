# |source| this file

set -ex
./build.sh
