#!/usr/bin/env bash

set -ex

sudo apt install libudev-dev -y
sudo apt install binutils-dev -y
sudo apt install libunwind-dev -y
