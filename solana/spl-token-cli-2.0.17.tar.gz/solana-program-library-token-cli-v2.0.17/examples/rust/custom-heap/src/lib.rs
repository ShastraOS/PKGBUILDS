//! A program demonstrating implementing a custom heap
#![deny(missing_docs)]

mod entrypoint;
pub mod processor;
