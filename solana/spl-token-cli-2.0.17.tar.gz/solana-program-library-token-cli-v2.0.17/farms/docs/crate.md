This Crate is a part of Solana Farms suite which is released along with [Solana Program Library](https://github.com/solana-labs/solana-program-library/blob/master/farms).

Detailed information about Solana Farms project and how to use this Crate is available in the [Documentation](https://github.com/solana-labs/solana-program-library/blob/master/farms/docs/intro.md).

If you still have questions please contact [Support](https://github.com/solana-labs/solana-program-library/blob/master/farms/docs/support.md).
