//! Official accounts and program ids

include!(concat!(
    env!(
        "OUT_DIR",
        "Please set OUT_DIR environment variable to the build script output path"
    ),
    "/constants.rs"
));
